=======
Classes
=======
.. automodule:: trabajador.Trabajador
    :members:
    :show-inheritance:
    :no-index:
    
.. automodule:: trabajador.Medico
    :members:
    :show-inheritance:
    :no-index:

.. automodule:: trabajador.Enfermera
    :members:
    :show-inheritance:
    :no-index:

