.. Trabajadores documentation master file, created by
   sphinx-quickstart on Tue Dec 17 19:36:24 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Trabajadores documentation
==========================

Add your content using ``reStructuredText`` syntax. See the
`reStructuredText <https://www.sphinx-doc.org/en/master/usage/restructuredtext/index.html>`_
documentation for details.

Documentacion Trabajadores
=======================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   app
   classes

Indices and tables
==================
:ref:`genindex`
:ref:`modindex`
:ref:`search`