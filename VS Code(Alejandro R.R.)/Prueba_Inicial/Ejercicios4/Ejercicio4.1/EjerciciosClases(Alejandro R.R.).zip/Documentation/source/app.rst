app
========
.. automodule:: main
    :members:
    :show-inheritance:

.. automodule:: trabajador
    :members:
    :show-inheritance: